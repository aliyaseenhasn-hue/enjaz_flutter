import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';
import '../../features/auth/data/models/user_model.dart';

class AuthState {
  final bool isLoggedIn;
  final UserModel? user;

  const AuthState({this.isLoggedIn = false, this.user});

  AuthState copyWith({bool? isLoggedIn, UserModel? user}) => AuthState(
        isLoggedIn: isLoggedIn ?? this.isLoggedIn,
        user: user ?? this.user,
      );
}

class AuthNotifier extends StateNotifier<AuthState> {
  final FlutterSecureStorage _storage;

  AuthNotifier(this._storage) : super(const AuthState()) {
    _initialize();
  }

  Future<void> _initialize() async {
    final token = await _storage.read(key: AppConstants.accessTokenKey);
    final userData = await _storage.read(key: AppConstants.userKey);
    if (token != null && userData != null) {
      final user = UserModel.fromJson(jsonDecode(userData));
      state = AuthState(isLoggedIn: true, user: user);
    }
  }

  Future<void> login(String accessToken, String refreshToken, UserModel user) async {
    await _storage.write(key: AppConstants.accessTokenKey, value: accessToken);
    await _storage.write(key: AppConstants.refreshTokenKey, value: refreshToken);
    await _storage.write(key: AppConstants.userKey, value: jsonEncode(user.toJson()));
    state = AuthState(isLoggedIn: true, user: user);
  }

  Future<void> logout() async {
    await _storage.deleteAll();
    state = const AuthState();
  }

  Future<void> updateUser(UserModel user) async {
    await _storage.write(key: AppConstants.userKey, value: jsonEncode(user.toJson()));
    state = state.copyWith(user: user);
  }
}

final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(const FlutterSecureStorage());
});
