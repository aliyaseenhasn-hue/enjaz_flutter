import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';

final secureStorageProvider = Provider((ref) => const FlutterSecureStorage());

final dioProvider = Provider<Dio>((ref) {
  final storage = ref.read(secureStorageProvider);
  final dio = Dio(BaseOptions(
    baseUrl: AppConstants.baseUrl,
    connectTimeout: const Duration(milliseconds: AppConstants.connectTimeout),
    receiveTimeout: const Duration(milliseconds: AppConstants.receiveTimeout),
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
  ));

  // Request interceptor - attach token
  dio.interceptors.add(InterceptorsWrapper(
    onRequest: (options, handler) async {
      final token = await storage.read(key: AppConstants.accessTokenKey);
      if (token != null) {
        options.headers['Authorization'] = 'Bearer $token';
      }
      handler.next(options);
    },
    onError: (error, handler) async {
      if (error.response?.statusCode == 401) {
        // Try refresh token
        try {
          final refreshToken = await storage.read(key: AppConstants.refreshTokenKey);
          if (refreshToken == null) {
            handler.next(error);
            return;
          }

          final refreshDio = Dio();
          final response = await refreshDio.post(
            '${AppConstants.baseUrl}/auth/token/refresh/',
            data: {'refresh': refreshToken},
          );

          final newAccess = response.data['access'];
          await storage.write(key: AppConstants.accessTokenKey, value: newAccess);

          // Retry original request
          final opts = error.requestOptions;
          opts.headers['Authorization'] = 'Bearer $newAccess';
          final retryResponse = await dio.fetch(opts);
          handler.resolve(retryResponse);
        } catch (e) {
          // Refresh failed - force logout
          await storage.deleteAll();
          handler.next(error);
        }
      } else {
        handler.next(error);
      }
    },
  ));

  return dio;
});

// Helper to extract error messages from API
String extractApiError(DioException e) {
  final data = e.response?.data;
  if (data is Map) {
    // DRF returns errors as {'field': ['message']} or {'error': 'message'}
    final values = data.values.toList();
    if (values.isNotEmpty) {
      final first = values.first;
      if (first is List && first.isNotEmpty) return first.first.toString();
      if (first is String) return first;
    }
  }
  switch (e.response?.statusCode) {
    case 400: return 'بيانات غير صحيحة';
    case 401: return 'يرجى تسجيل الدخول';
    case 403: return 'غير مصرح لك بهذا الإجراء';
    case 404: return 'غير موجود';
    case 429: return 'طلبات كثيرة جداً، حاول لاحقاً';
    case 500: return 'خطأ في الخادم';
    default: return 'حدث خطأ، تحقق من اتصالك';
  }
}
