class AppConstants {
  // API
  static const String baseUrl = 'https://your-domain.railway.app/api';
  static const String wsBaseUrl = 'wss://your-domain.railway.app/ws';

  // Storage Keys
  static const String accessTokenKey = 'access_token';
  static const String refreshTokenKey = 'refresh_token';
  static const String userKey = 'user_data';

  // Pagination
  static const int pageSize = 20;

  // Timeouts
  static const int connectTimeout = 30000;
  static const int receiveTimeout = 30000;

  // Map
  static const double defaultLat = 33.3152; // Baghdad
  static const double defaultLng = 44.3661;
  static const double defaultZoom = 12.0;

  // Roles
  static const String roleSeeker = 'seeker';
  static const String roleProfessional = 'professional';

  // Request Status
  static const String statusPending = 'pending';
  static const String statusAccepted = 'accepted';
  static const String statusNegotiating = 'negotiating';
  static const String statusConfirmed = 'confirmed';
  static const String statusInProgress = 'in_progress';
  static const String statusCompleted = 'completed';
  static const String statusCancelled = 'cancelled';
  static const String statusRejected = 'rejected';
}
