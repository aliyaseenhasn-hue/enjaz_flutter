import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/auth_state.dart';

class MainScreen extends ConsumerWidget {
  final Widget child;
  const MainScreen({super.key, required this.child});

  int _locationIndex(BuildContext context, bool isProfessional) {
    final location = GoRouterState.of(context).matchedLocation;
    if (location.startsWith('/requests')) return 1;
    if (location.startsWith('/chat')) return 2;
    if (location.startsWith('/notifications')) return 3;
    if (location.startsWith('/professional-me')) return isProfessional ? 4 : -1;
    if (location.startsWith('/profile')) return isProfessional ? 5 : 4;
    return 0;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).user;
    final isProfessional = user?.isProfessional ?? false;
    final currentIndex = _locationIndex(context, isProfessional);

    final destinations = [
      const NavigationDestination(
        icon: Icon(Icons.search_outlined),
        selectedIcon: Icon(Icons.search),
        label: 'استكشاف',
      ),
      const NavigationDestination(
        icon: Icon(Icons.work_outline),
        selectedIcon: Icon(Icons.work),
        label: 'طلباتي',
      ),
      const NavigationDestination(
        icon: Icon(Icons.chat_bubble_outline),
        selectedIcon: Icon(Icons.chat_bubble),
        label: 'المحادثات',
      ),
      const NavigationDestination(
        icon: Icon(Icons.notifications_outlined),
        selectedIcon: Icon(Icons.notifications),
        label: 'الإشعارات',
      ),
      if (isProfessional)
        const NavigationDestination(
          icon: Icon(Icons.engineering_outlined),
          selectedIcon: Icon(Icons.engineering),
          label: 'ملفي المهني',
        ),
      const NavigationDestination(
        icon: Icon(Icons.person_outline),
        selectedIcon: Icon(Icons.person),
        label: 'حسابي',
      ),
    ];

    void onNav(int i) {
      if (isProfessional) {
        switch (i) {
          case 0: context.go('/home'); break;
          case 1: context.go('/requests'); break;
          case 2: context.go('/chat'); break;
          case 3: context.go('/notifications'); break;
          case 4: context.go('/professional-me'); break;
          case 5: context.go('/profile'); break;
        }
      } else {
        switch (i) {
          case 0: context.go('/home'); break;
          case 1: context.go('/requests'); break;
          case 2: context.go('/chat'); break;
          case 3: context.go('/notifications'); break;
          case 4: context.go('/profile'); break;
        }
      }
    }

    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex < 0 ? 0 : currentIndex,
        onDestinationSelected: onNav,
        destinations: destinations,
      ),
    );
  }
}
