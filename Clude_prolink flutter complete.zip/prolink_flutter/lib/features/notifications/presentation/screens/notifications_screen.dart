// notifications_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/api_client.dart';

class NotificationItem {
  final String id, title, body;
  final bool isRead;
  final String createdAt;
  final Map<String, dynamic> data;

  const NotificationItem({required this.id, required this.title, required this.body, required this.isRead, required this.createdAt, required this.data});

  factory NotificationItem.fromJson(Map<String, dynamic> json) => NotificationItem(
        id: json['id'] ?? '',
        title: json['title'] ?? '',
        body: json['body'] ?? '',
        isRead: json['is_read'] ?? false,
        createdAt: json['created_at'] ?? '',
        data: json['data'] ?? {},
      );
}

final notificationsProvider = FutureProvider<List<NotificationItem>>((ref) async {
  final dio = ref.read(dioProvider);
  final res = await dio.get('/notifications/');
  final data = res.data['results'] ?? res.data;
  return (data as List).map((e) => NotificationItem.fromJson(e)).toList();
});

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notificationsAsync = ref.watch(notificationsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الإشعارات'),
        actions: [
          TextButton(
            onPressed: () async {
              await ref.read(dioProvider).post('/notifications/read-all/');
              ref.invalidate(notificationsProvider);
            },
            child: const Text('تحديد الكل كمقروء'),
          ),
        ],
      ),
      body: notificationsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (notifs) {
          if (notifs.isEmpty) {
            return const Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('🔔', style: TextStyle(fontSize: 48)),
                SizedBox(height: 12),
                Text('لا توجد إشعارات', style: TextStyle(fontFamily: 'Cairo', color: AppColors.textSecondary)),
              ]),
            );
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(notificationsProvider),
            child: ListView.separated(
              itemCount: notifs.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) => _NotifTile(notif: notifs[i], onTap: () async {
                if (!notifs[i].isRead) {
                  await ref.read(dioProvider).post('/notifications/${notifs[i].id}/read/');
                  ref.invalidate(notificationsProvider);
                }
              }),
            ),
          );
        },
      ),
    );
  }
}

class _NotifTile extends StatelessWidget {
  final NotificationItem notif;
  final VoidCallback onTap;

  const _NotifTile({required this.notif, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      tileColor: notif.isRead ? null : AppColors.primaryLight.withOpacity(0.3),
      leading: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
        child: const Icon(Icons.notifications_outlined, color: AppColors.primary, size: 22),
      ),
      title: Text(notif.title, style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w600, fontSize: 14)),
      subtitle: Text(notif.body, style: const TextStyle(fontFamily: 'Cairo', fontSize: 13, color: AppColors.textSecondary)),
      trailing: !notif.isRead
          ? Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle))
          : null,
    );
  }
}
