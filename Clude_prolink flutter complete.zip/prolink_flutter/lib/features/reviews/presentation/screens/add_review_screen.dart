import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:go_router/go_router.dart';
import 'package:dio/dio.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/api_client.dart';

class AddReviewScreen extends ConsumerStatefulWidget {
  final Map<String, dynamic> extra;

  const AddReviewScreen({super.key, required this.extra});

  @override
  ConsumerState<AddReviewScreen> createState() => _AddReviewScreenState();
}

class _AddReviewScreenState extends ConsumerState<AddReviewScreen> {
  final _commentCtrl = TextEditingController();
  double _rating = 5.0;
  bool _loading = false;

  String get _professionalId => widget.extra['professional_id'] as String;
  String get _professionalName => widget.extra['professional_name'] as String? ?? 'المهني';
  String? get _requestId => widget.extra['request_id'] as String?;

  @override
  void dispose() {
    _commentCtrl.dispose();
    super.dispose();
  }

  String _ratingLabel(double r) {
    if (r >= 5) return 'ممتاز جداً';
    if (r >= 4) return 'جيد جداً';
    if (r >= 3) return 'جيد';
    if (r >= 2) return 'مقبول';
    return 'ضعيف';
  }

  Color _ratingColor(double r) {
    if (r >= 4) return AppColors.secondary;
    if (r >= 3) return AppColors.warning;
    return AppColors.error;
  }

  Future<void> _submit() async {
    if (_commentCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى كتابة تعليق')),
      );
      return;
    }

    setState(() => _loading = true);
    try {
      final dio = ref.read(dioProvider);
      await dio.post('/reviews/create/', data: {
        'professional': _professionalId,
        'rating': _rating.round(),
        'comment': _commentCtrl.text.trim(),
        if (_requestId != null) 'request': _requestId,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم إرسال التقييم، شكراً لك!'),
            backgroundColor: AppColors.secondary,
          ),
        );
        context.pop(true); // return true = review submitted
      }
    } catch (e) {
      if (mounted) {
        String msg = 'حدث خطأ';
        if (e is DioException) msg = extractApiError(e);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(msg)),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تقييم المهني')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Professional name
            const SizedBox(height: 8),
            Text(
              'كيف كانت تجربتك مع',
              style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 16,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              _professionalName,
              style: const TextStyle(
                fontFamily: 'Cairo',
                fontSize: 22,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 32),

            // Star rating
            RatingBar.builder(
              initialRating: _rating,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: false,
              itemCount: 5,
              itemSize: 48,
              itemPadding: const EdgeInsets.symmetric(horizontal: 6),
              itemBuilder: (context, _) => const Icon(Icons.star, color: AppColors.starColor),
              onRatingUpdate: (r) => setState(() => _rating = r),
            ),
            const SizedBox(height: 12),

            // Rating label
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: Text(
                _ratingLabel(_rating),
                key: ValueKey(_rating.round()),
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: _ratingColor(_rating),
                ),
              ),
            ),
            const SizedBox(height: 32),

            // Rating dots indicator
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (i) {
                final active = i < _rating.round();
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: active ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: active ? _ratingColor(_rating) : AppColors.border,
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              }),
            ),
            const SizedBox(height: 32),

            // Comment field
            TextFormField(
              controller: _commentCtrl,
              maxLines: 5,
              maxLength: 500,
              textDirection: TextDirection.rtl,
              style: const TextStyle(fontFamily: 'Cairo'),
              decoration: InputDecoration(
                hintText: 'شارك تجربتك مع الآخرين...',
                hintStyle: const TextStyle(fontFamily: 'Cairo', color: AppColors.textHint),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.border),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.primary, width: 2),
                ),
                filled: true,
                fillColor: AppColors.surface,
                contentPadding: const EdgeInsets.all(16),
              ),
            ),
            const SizedBox(height: 24),

            // Submit button
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _loading ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 0,
                ),
                child: _loading
                    ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
                    : const Text(
                        'إرسال التقييم',
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
