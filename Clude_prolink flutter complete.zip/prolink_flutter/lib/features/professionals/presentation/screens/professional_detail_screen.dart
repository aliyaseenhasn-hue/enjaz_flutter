import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/auth_state.dart';
import '../../data/models/professional_model.dart';
import '../../data/repositories/professionals_repository.dart';

final professionalDetailProvider = FutureProvider.family<ProfessionalDetailModel, String>((ref, id) {
  return ref.read(professionalsRepositoryProvider).getProfessionalDetail(id);
});

class ProfessionalDetailScreen extends ConsumerWidget {
  final String id;
  const ProfessionalDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final detailAsync = ref.watch(professionalDetailProvider(id));
    final currentUser = ref.watch(authStateProvider).user;

    return detailAsync.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('خطأ: $e'))),
      data: (pro) => Scaffold(
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 280,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                background: Stack(
                  fit: StackFit.expand,
                  children: [
                    pro.profilePhoto != null
                        ? CachedNetworkImage(imageUrl: pro.profilePhoto!, fit: BoxFit.cover)
                        : Container(color: AppColors.primaryLight, child: Center(child: Text(pro.fullName[0], style: const TextStyle(fontSize: 80, color: AppColors.primary, fontWeight: FontWeight.w700)))),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 20,
                      left: 20,
                      right: 20,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(pro.fullName, style: const TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white)),
                              const SizedBox(width: 8),
                              if (pro.isAvailableNow)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(color: AppColors.secondary, borderRadius: BorderRadius.circular(10)),
                                  child: const Text('متاح الآن', style: TextStyle(fontFamily: 'Cairo', color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                                ),
                            ],
                          ),
                          Text(pro.title, style: TextStyle(fontFamily: 'Cairo', fontSize: 15, color: Colors.white.withOpacity(0.85))),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Stats Row
                    Row(
                      children: [
                        _StatBox(value: pro.avgRating.toStringAsFixed(1), label: 'التقييم', icon: '⭐'),
                        _StatBox(value: '${pro.totalReviews}', label: 'مراجعة', icon: '💬'),
                        _StatBox(value: '${pro.totalJobs}', label: 'عمل منجز', icon: '✅'),
                        _StatBox(value: '${pro.experienceYears}س', label: 'خبرة', icon: '🏆'),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Categories
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: pro.categories.map((c) => Chip(
                        avatar: Text(c.icon),
                        label: Text(c.nameAr, style: const TextStyle(fontFamily: 'Cairo', fontSize: 13)),
                        backgroundColor: AppColors.primaryLight,
                      )).toList(),
                    ),
                    const SizedBox(height: 20),

                    // Location & Rate
                    _InfoRow(icon: Icons.location_on_outlined, text: pro.city),
                    if (pro.hourlyRate != null)
                      _InfoRow(icon: Icons.payments_outlined, text: '${pro.hourlyRate!.toStringAsFixed(0)} د.ع / ساعة'),

                    // Bio
                    if (pro.bio != null && pro.bio!.isNotEmpty) ...[
                      const SizedBox(height: 20),
                      const Text('نبذة عني', style: TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 8),
                      Text(pro.bio!, style: const TextStyle(fontFamily: 'Cairo', fontSize: 14, color: AppColors.textSecondary, height: 1.6)),
                    ],

                    // Portfolio
                    if (pro.portfolioItems.isNotEmpty) ...[
                      const SizedBox(height: 24),
                      const Text('أعمال سابقة', style: TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 140,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: pro.portfolioItems.length,
                          itemBuilder: (_, i) {
                            final item = pro.portfolioItems[i];
                            return Container(
                              width: 140,
                              margin: const EdgeInsets.only(left: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                image: DecorationImage(image: CachedNetworkImageProvider(item.image), fit: BoxFit.cover),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                    const SizedBox(height: 100),
                  ],
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: currentUser?.id != id
            ? SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () async {
                            // Start chat
                            final repo = ref.read(professionalsRepositoryProvider);
                          },
                          icon: const Icon(Icons.chat_bubble_outline),
                          label: const Text('مراسلة'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        flex: 2,
                        child: ElevatedButton.icon(
                          onPressed: () => context.push('/requests/create', extra: {
                            'professional_id': pro.id,
                            'professional_name': pro.fullName,
                          }),
                          icon: const Icon(Icons.add_task),
                          label: const Text('طلب خدمة'),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            : null,
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String value, label, icon;
  const _StatBox({required this.value, required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.only(left: 8),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Text(icon, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontFamily: 'Cairo', fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
            Text(label, style: const TextStyle(fontFamily: 'Cairo', fontSize: 11, color: AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;
  const _InfoRow({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppColors.textSecondary),
          const SizedBox(width: 8),
          Text(text, style: const TextStyle(fontFamily: 'Cairo', color: AppColors.textSecondary, fontSize: 14)),
        ],
      ),
    );
  }
}
