import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dio/dio.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/auth_state.dart';
import '../../../../core/utils/api_client.dart';
import '../../data/models/professional_model.dart';

// ─── Provider ────────────────────────────────────────────────────────────────

final myProfessionalProfileProvider =
    FutureProvider<ProfessionalDetailModel>((ref) async {
  final dio = ref.read(dioProvider);
  final res = await dio.get('/professionals/me/');
  return ProfessionalDetailModel.fromJson(res.data);
});

// ─── Screen ──────────────────────────────────────────────────────────────────

class ProfessionalMeScreen extends ConsumerStatefulWidget {
  const ProfessionalMeScreen({super.key});

  @override
  ConsumerState<ProfessionalMeScreen> createState() =>
      _ProfessionalMeScreenState();
}

class _ProfessionalMeScreenState extends ConsumerState<ProfessionalMeScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateProvider).user;
    final profileAsync = ref.watch(myProfessionalProfileProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('ملفي المهني'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_outlined),
            onPressed: () =>
                ref.invalidate(myProfessionalProfileProvider),
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          labelStyle: const TextStyle(
              fontFamily: 'Cairo', fontWeight: FontWeight.w600),
          unselectedLabelStyle:
              const TextStyle(fontFamily: 'Cairo'),
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          tabs: const [
            Tab(text: 'الملف'),
            Tab(text: 'التوفر'),
            Tab(text: 'المعرض'),
          ],
        ),
      ),
      body: profileAsync.when(
        loading: () =>
            const Center(child: CircularProgressIndicator()),
        error: (e, _) => _buildError(),
        data: (profile) => TabBarView(
          controller: _tabs,
          children: [
            _ProfileTab(profile: profile),
            _AvailabilityTab(profile: profile),
            _PortfolioTab(profile: profile),
          ],
        ),
      ),
    );
  }

  Widget _buildError() => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline,
                size: 48, color: AppColors.error),
            const SizedBox(height: 12),
            const Text('تعذر تحميل الملف المهني',
                style: TextStyle(fontFamily: 'Cairo')),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () =>
                  ref.invalidate(myProfessionalProfileProvider),
              child: const Text('إعادة المحاولة',
                  style: TextStyle(fontFamily: 'Cairo')),
            ),
          ],
        ),
      );
}

// ─── Profile Tab ─────────────────────────────────────────────────────────────

class _ProfileTab extends ConsumerStatefulWidget {
  final ProfessionalDetailModel profile;
  const _ProfileTab({required this.profile});

  @override
  ConsumerState<_ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends ConsumerState<_ProfileTab> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleCtrl;
  late final TextEditingController _bioCtrl;
  late final TextEditingController _hourlyRateCtrl;
  late final TextEditingController _experienceCtrl;
  late final TextEditingController _cityCtrl;
  bool _loading = false;

  final List<String> _iraqiCities = [
    'بغداد', 'البصرة', 'الموصل', 'أربيل', 'النجف',
    'كربلاء', 'الحلة', 'كركوك', 'الناصرية', 'العمارة',
    'الديوانية', 'الكوت', 'السماوة', 'تكريت', 'الرمادي',
  ];

  @override
  void initState() {
    super.initState();
    final p = widget.profile;
    _titleCtrl = TextEditingController(text: p.title);
    _bioCtrl = TextEditingController(text: p.bio ?? '');
    _hourlyRateCtrl =
        TextEditingController(text: p.hourlyRate?.toString() ?? '');
    _experienceCtrl =
        TextEditingController(text: p.experienceYears.toString());
    _cityCtrl = TextEditingController(text: p.city);
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _bioCtrl.dispose();
    _hourlyRateCtrl.dispose();
    _experienceCtrl.dispose();
    _cityCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final dio = ref.read(dioProvider);
      await dio.put('/professionals/me/', data: {
        'title': _titleCtrl.text.trim(),
        'bio': _bioCtrl.text.trim(),
        'hourly_rate': double.tryParse(_hourlyRateCtrl.text) ?? 0,
        'experience_years': int.tryParse(_experienceCtrl.text) ?? 0,
        'city': _cityCtrl.text.trim(),
      });
      ref.invalidate(myProfessionalProfileProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم تحديث الملف المهني'),
            backgroundColor: AppColors.secondary,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(
                  e is DioException ? extractApiError(e) : 'حدث خطأ')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Stats row
            Row(
              children: [
                _StatCard(
                    value: widget.profile.avgRating.toStringAsFixed(1),
                    label: 'التقييم',
                    icon: Icons.star,
                    color: AppColors.starColor),
                const SizedBox(width: 12),
                _StatCard(
                    value: widget.profile.totalJobs.toString(),
                    label: 'الوظائف',
                    icon: Icons.work_outline,
                    color: AppColors.primary),
                const SizedBox(width: 12),
                _StatCard(
                    value: widget.profile.totalReviews.toString(),
                    label: 'التقييمات',
                    icon: Icons.reviews_outlined,
                    color: AppColors.secondary),
              ],
            ),
            const SizedBox(height: 24),

            _sectionTitle('المعلومات المهنية'),
            const SizedBox(height: 12),

            _field(
              controller: _titleCtrl,
              label: 'المسمى المهني',
              icon: Icons.badge_outlined,
              validator: (v) =>
                  v?.trim().isEmpty == true ? 'المسمى مطلوب' : null,
            ),
            const SizedBox(height: 12),
            _dropdownCity(),
            const SizedBox(height: 12),

            Row(children: [
              Expanded(
                child: _field(
                  controller: _hourlyRateCtrl,
                  label: 'السعر/ساعة (IQD)',
                  icon: Icons.payments_outlined,
                  keyboardType: TextInputType.number,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _field(
                  controller: _experienceCtrl,
                  label: 'سنوات الخبرة',
                  icon: Icons.timeline_outlined,
                  keyboardType: TextInputType.number,
                ),
              ),
            ]),
            const SizedBox(height: 12),
            _field(
              controller: _bioCtrl,
              label: 'نبذة مهنية',
              icon: Icons.description_outlined,
              maxLines: 4,
              hint: 'اكتب نبذة عن خبراتك وتخصصك...',
            ),
            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _loading ? null : _save,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  elevation: 0,
                ),
                child: _loading
                    ? const CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2)
                    : const Text('حفظ التغييرات',
                        style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 16,
                            fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String t) => Text(t,
      style: const TextStyle(
          fontFamily: 'Cairo',
          fontSize: 16,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary));

  Widget _field({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    int maxLines = 1,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: keyboardType,
      validator: validator,
      textDirection: TextDirection.rtl,
      style: const TextStyle(fontFamily: 'Cairo'),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: AppColors.textSecondary),
        labelStyle: const TextStyle(fontFamily: 'Cairo'),
        hintStyle:
            const TextStyle(fontFamily: 'Cairo', color: AppColors.textHint),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.border)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.border)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide:
                const BorderSide(color: AppColors.primary, width: 2)),
        filled: true,
        fillColor: AppColors.surface,
      ),
    );
  }

  Widget _dropdownCity() {
    return DropdownButtonFormField<String>(
      value: _iraqiCities.contains(_cityCtrl.text) ? _cityCtrl.text : null,
      style: const TextStyle(
          fontFamily: 'Cairo', color: AppColors.textPrimary),
      decoration: InputDecoration(
        labelText: 'المدينة',
        prefixIcon: const Icon(Icons.location_on_outlined,
            color: AppColors.textSecondary),
        labelStyle: const TextStyle(fontFamily: 'Cairo'),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppColors.border)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide:
                const BorderSide(color: AppColors.primary, width: 2)),
        filled: true,
        fillColor: AppColors.surface,
      ),
      items: _iraqiCities
          .map((c) => DropdownMenuItem(
              value: c,
              child: Text(c, style: const TextStyle(fontFamily: 'Cairo'))))
          .toList(),
      onChanged: (v) {
        if (v != null) _cityCtrl.text = v;
      },
    );
  }
}

// ─── Availability Tab ─────────────────────────────────────────────────────────

class _AvailabilityTab extends ConsumerStatefulWidget {
  final ProfessionalDetailModel profile;
  const _AvailabilityTab({required this.profile});

  @override
  ConsumerState<_AvailabilityTab> createState() => _AvailabilityTabState();
}

class _AvailabilityTabState extends ConsumerState<_AvailabilityTab> {
  String _availability = 'offline';
  bool _loading = false;

  final _options = [
    {'value': 'online', 'label': 'متاح الآن', 'icon': Icons.circle, 'color': AppColors.onlineGreen},
    {'value': 'busy', 'label': 'مشغول', 'icon': Icons.do_not_disturb_on, 'color': AppColors.warning},
    {'value': 'offline', 'label': 'غير متاح', 'icon': Icons.offline_bolt, 'color': AppColors.offlineGray},
  ];

  @override
  void initState() {
    super.initState();
    _availability = widget.profile.availability;
  }

  Future<void> _setAvailability(String v) async {
    setState(() {
      _availability = v;
      _loading = true;
    });
    try {
      final dio = ref.read(dioProvider);
      await dio.post('/professionals/me/availability/', data: {'availability': v});
      ref.invalidate(myProfessionalProfileProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('تم تحديث حالة التوفر'),
            backgroundColor: AppColors.secondary,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تحديث الحالة')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'حالة التوفر',
            style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 18,
                fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          Text(
            'تحكم في ظهورك للعملاء وقبول الطلبات الجديدة',
            style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 13,
                color: AppColors.textSecondary),
          ),
          const SizedBox(height: 24),
          ..._options.map((opt) {
            final val = opt['value'] as String;
            final selected = _availability == val;
            return GestureDetector(
              onTap: _loading ? null : () => _setAvailability(val),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: selected ? AppColors.primaryLight : AppColors.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: selected ? AppColors.primary : AppColors.border,
                    width: selected ? 2 : 1,
                  ),
                  boxShadow: selected
                      ? [BoxShadow(color: AppColors.primary.withOpacity(0.1), blurRadius: 8, offset: const Offset(0, 2))]
                      : [],
                ),
                child: Row(
                  children: [
                    Icon(opt['icon'] as IconData,
                        color: opt['color'] as Color, size: 28),
                    const SizedBox(width: 16),
                    Text(
                      opt['label'] as String,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 16,
                        fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                        color: selected ? AppColors.primary : AppColors.textPrimary,
                      ),
                    ),
                    const Spacer(),
                    if (selected)
                      const Icon(Icons.check_circle, color: AppColors.primary),
                    if (_loading && selected)
                      const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ─── Portfolio Tab ────────────────────────────────────────────────────────────

class _PortfolioTab extends ConsumerStatefulWidget {
  final ProfessionalDetailModel profile;
  const _PortfolioTab({required this.profile});

  @override
  ConsumerState<_PortfolioTab> createState() => _PortfolioTabState();
}

class _PortfolioTabState extends ConsumerState<_PortfolioTab> {
  bool _uploading = false;

  Future<void> _addPortfolioItem() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(
        source: ImageSource.gallery, imageQuality: 80);
    if (image == null) return;

    // Title dialog
    final titleCtrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('عنوان المشروع',
            style: TextStyle(fontFamily: 'Cairo')),
        content: TextField(
          controller: titleCtrl,
          textDirection: TextDirection.rtl,
          decoration: const InputDecoration(
            hintText: 'أدخل عنواناً لهذا المشروع',
            hintStyle: TextStyle(fontFamily: 'Cairo'),
          ),
          style: const TextStyle(fontFamily: 'Cairo'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء', style: TextStyle(fontFamily: 'Cairo')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('رفع', style: TextStyle(fontFamily: 'Cairo')),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    setState(() => _uploading = true);
    try {
      final dio = ref.read(dioProvider);
      final formData = FormData.fromMap({
        'title': titleCtrl.text.trim().isEmpty ? 'مشروع جديد' : titleCtrl.text.trim(),
        'image': await MultipartFile.fromFile(image.path, filename: 'portfolio.jpg'),
      });
      await dio.post('/professionals/me/portfolio/', data: formData);
      ref.invalidate(myProfessionalProfileProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('تمت إضافة المشروع'),
              backgroundColor: AppColors.secondary),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر رفع الصورة')),
        );
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.profile.portfolioItems;

    return Stack(
      children: [
        items.isEmpty
            ? Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.photo_library_outlined,
                        size: 64, color: AppColors.textHint),
                    const SizedBox(height: 12),
                    const Text('لا توجد مشاريع في معرضك بعد',
                        style: TextStyle(
                            fontFamily: 'Cairo',
                            color: AppColors.textSecondary)),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: _uploading ? null : _addPortfolioItem,
                      icon: const Icon(Icons.add_photo_alternate_outlined),
                      label: const Text('أضف مشروعاً',
                          style: TextStyle(fontFamily: 'Cairo')),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                ),
              )
            : GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.85,
                ),
                itemCount: items.length + 1,
                itemBuilder: (ctx, i) {
                  if (i == items.length) {
                    // Add button
                    return GestureDetector(
                      onTap: _uploading ? null : _addPortfolioItem,
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: AppColors.border,
                              style: BorderStyle.solid),
                          borderRadius: BorderRadius.circular(12),
                          color: AppColors.background,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.add_circle_outline,
                                size: 36, color: AppColors.primary),
                            const SizedBox(height: 8),
                            const Text('إضافة مشروع',
                                style: TextStyle(
                                    fontFamily: 'Cairo',
                                    color: AppColors.primary,
                                    fontSize: 12)),
                          ],
                        ),
                      ),
                    );
                  }
                  final item = items[i];
                  return Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      image: DecorationImage(
                        image: NetworkImage(item.image),
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black.withOpacity(0.6),
                          ],
                        ),
                      ),
                      padding: const EdgeInsets.all(10),
                      alignment: Alignment.bottomRight,
                      child: Text(
                        item.title,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  );
                },
              ),
        if (_uploading)
          Container(
            color: Colors.black.withOpacity(0.3),
            child: const Center(
              child: CircularProgressIndicator(color: Colors.white),
            ),
          ),
      ],
    );
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.value,
    required this.label,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 6),
            Text(value,
                style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: color)),
            Text(label,
                style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 11,
                    color: AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }
}
