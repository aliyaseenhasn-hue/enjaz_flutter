import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/auth_state.dart';
import '../../data/models/professional_model.dart';
import '../../data/repositories/professionals_repository.dart';

class ProfessionalListScreen extends ConsumerStatefulWidget {
  const ProfessionalListScreen({super.key});

  @override
  ConsumerState<ProfessionalListScreen> createState() => _ProfessionalListScreenState();
}

class _ProfessionalListScreenState extends ConsumerState<ProfessionalListScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateProvider).user;
    final filter = ref.watch(professionalsFilterProvider);
    final professionalsAsync = ref.watch(professionalsProvider);
    final categoriesAsync = ref.watch(categoriesProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true,
            snap: true,
            backgroundColor: AppColors.surface,
            expandedHeight: 160,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                color: AppColors.surface,
                padding: const EdgeInsets.fromLTRB(20, 60, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'مرحباً ${user?.fullName.split(' ').first ?? ''} 👋',
                      style: const TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 4),
                    const Text('ابحث عن المهني المناسب', style: TextStyle(fontFamily: 'Cairo', color: AppColors.textSecondary)),
                    const SizedBox(height: 14),
                    TextField(
                      controller: _searchCtrl,
                      onChanged: (v) => ref.read(professionalsFilterProvider.notifier).state = filter.copyWith(search: v, page: 1),
                      decoration: InputDecoration(
                        hintText: 'ابحث عن سباك، كهربائي...',
                        prefixIcon: const Icon(Icons.search, color: AppColors.textHint),
                        suffixIcon: _searchCtrl.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear, size: 18),
                                onPressed: () {
                                  _searchCtrl.clear();
                                  ref.read(professionalsFilterProvider.notifier).state = filter.copyWith(search: '', page: 1);
                                })
                            : null,
                        contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Categories
          SliverToBoxAdapter(
            child: categoriesAsync.when(
              data: (cats) => SizedBox(
                height: 50,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  itemCount: cats.length + 1,
                  itemBuilder: (_, i) {
                    if (i == 0) {
                      return _CategoryChip(
                        label: 'الكل',
                        icon: '🌟',
                        selected: filter.categoryId == null,
                        onTap: () => ref.read(professionalsFilterProvider.notifier).state = filter.copyWith(clearCategory: true, page: 1),
                      );
                    }
                    final cat = cats[i - 1];
                    return _CategoryChip(
                      label: cat.nameAr,
                      icon: cat.icon,
                      selected: filter.categoryId == cat.id,
                      onTap: () => ref.read(professionalsFilterProvider.notifier).state = filter.copyWith(categoryId: cat.id, page: 1),
                    );
                  },
                ),
              ),
              loading: () => const SizedBox(height: 50),
              error: (_, __) => const SizedBox(),
            ),
          ),

          // Filter bar
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                children: [
                  _FilterChip(
                    label: 'متاح الآن',
                    active: filter.availableNow == true,
                    onTap: () => ref.read(professionalsFilterProvider.notifier).state =
                        filter.copyWith(availableNow: filter.availableNow == true ? null : true, page: 1),
                  ),
                  const SizedBox(width: 8),
                  _FilterChip(
                    label: 'الأعلى تقييماً',
                    active: filter.ordering == '-avg_rating',
                    onTap: () => ref.read(professionalsFilterProvider.notifier).state = filter.copyWith(ordering: '-avg_rating', page: 1),
                  ),
                  const SizedBox(width: 8),
                  _FilterChip(
                    label: 'الأكثر خبرة',
                    active: filter.ordering == '-experience_years',
                    onTap: () => ref.read(professionalsFilterProvider.notifier).state = filter.copyWith(ordering: '-experience_years', page: 1),
                  ),
                ],
              ),
            ),
          ),

          // Results
          professionalsAsync.when(
            data: (data) {
              final pros = data['results'] as List<ProfessionalListModel>;
              if (pros.isEmpty) {
                return const SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('🔍', style: TextStyle(fontSize: 48)),
                        SizedBox(height: 12),
                        Text('لا يوجد مهنيون مطابقون', style: TextStyle(fontFamily: 'Cairo', color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                );
              }
              return SliverPadding(
                padding: const EdgeInsets.all(16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (_, i) => ProfessionalCard(professional: pros[i]),
                    childCount: pros.length,
                  ),
                ),
              );
            },
            loading: () => SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (_, i) => const _ShimmerCard(),
                  childCount: 5,
                ),
              ),
            ),
            error: (e, _) => SliverFillRemaining(
              child: Center(child: Text('حدث خطأ: $e')),
            ),
          ),
        ],
      ),
    );
  }
}

class ProfessionalCard extends StatelessWidget {
  final ProfessionalListModel professional;
  const ProfessionalCard({super.key, required this.professional});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/professionals/${professional.id}'),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.cardBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: AppColors.primaryLight,
                  backgroundImage: professional.profilePhoto != null
                      ? CachedNetworkImageProvider(professional.profilePhoto!)
                      : null,
                  child: professional.profilePhoto == null
                      ? Text(professional.fullName[0], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.primary))
                      : null,
                ),
                if (professional.isAvailableNow)
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 14, height: 14,
                      decoration: BoxDecoration(
                        color: AppColors.onlineGreen,
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 2),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(professional.fullName, style: const TextStyle(fontFamily: 'Cairo', fontSize: 15, fontWeight: FontWeight.w600)),
                  Text(professional.title, style: const TextStyle(fontFamily: 'Cairo', fontSize: 13, color: AppColors.textSecondary)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, size: 15, color: AppColors.starColor),
                      const SizedBox(width: 2),
                      Text('${professional.avgRating.toStringAsFixed(1)}', style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, fontWeight: FontWeight.w600)),
                      Text(' (${professional.totalReviews})', style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppColors.textHint)),
                      const SizedBox(width: 8),
                      const Icon(Icons.location_on_outlined, size: 13, color: AppColors.textHint),
                      Text(professional.city, style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppColors.textHint)),
                    ],
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (professional.hourlyRate != null)
                  Text(
                    '${professional.hourlyRate!.toStringAsFixed(0)} د.ع',
                    style: const TextStyle(fontFamily: 'Cairo', fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.primary),
                  ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: professional.isAvailableNow ? AppColors.secondaryLight : AppColors.divider,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    professional.isAvailableNow ? 'متاح' : 'غير متاح',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: professional.isAvailableNow ? AppColors.secondary : AppColors.textHint,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label, icon;
  final bool selected;
  final VoidCallback onTap;
  const _CategoryChip({required this.label, required this.icon, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : AppColors.divider,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            Text(icon, style: const TextStyle(fontSize: 14)),
            const SizedBox(width: 4),
            Text(label, style: TextStyle(fontFamily: 'Cairo', fontSize: 13, fontWeight: FontWeight.w600, color: selected ? Colors.white : AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: active ? AppColors.primaryLight : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? AppColors.primary : AppColors.border),
        ),
        child: Text(label, style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: active ? AppColors.primary : AppColors.textSecondary, fontWeight: active ? FontWeight.w600 : FontWeight.w400)),
      ),
    );
  }
}

class _ShimmerCard extends StatelessWidget {
  const _ShimmerCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      height: 100,
      decoration: BoxDecoration(color: AppColors.shimmerBase, borderRadius: BorderRadius.circular(16)),
    );
  }
}
