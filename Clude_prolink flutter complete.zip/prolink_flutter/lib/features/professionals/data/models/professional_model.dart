class CategoryModel {
  final int id;
  final String nameAr;
  final String icon;

  const CategoryModel({required this.id, required this.nameAr, required this.icon});

  factory CategoryModel.fromJson(Map<String, dynamic> json) => CategoryModel(
        id: json['id'],
        nameAr: json['name_ar'] ?? '',
        icon: json['icon'] ?? '',
      );
}

class ProfessionalListModel {
  final String id;
  final String fullName;
  final String? profilePhoto;
  final List<CategoryModel> categories;
  final String title;
  final String city;
  final double? hourlyRate;
  final int experienceYears;
  final double avgRating;
  final int totalReviews;
  final int totalJobs;
  final bool isAvailableNow;
  final String availability;
  final bool isOnline;
  final double? distanceKm;

  const ProfessionalListModel({
    required this.id,
    required this.fullName,
    this.profilePhoto,
    required this.categories,
    required this.title,
    required this.city,
    this.hourlyRate,
    required this.experienceYears,
    required this.avgRating,
    required this.totalReviews,
    required this.totalJobs,
    required this.isAvailableNow,
    required this.availability,
    required this.isOnline,
    this.distanceKm,
  });

  factory ProfessionalListModel.fromJson(Map<String, dynamic> json) {
    final user = json['user'] ?? {};
    return ProfessionalListModel(
      id: json['id'] ?? '',
      fullName: user['full_name'] ?? '',
      profilePhoto: user['profile_photo'],
      categories: (json['categories'] as List? ?? [])
          .map((c) => CategoryModel.fromJson(c))
          .toList(),
      title: json['title'] ?? '',
      city: json['city'] ?? '',
      hourlyRate: json['hourly_rate'] != null ? double.tryParse(json['hourly_rate'].toString()) : null,
      experienceYears: json['experience_years'] ?? 0,
      avgRating: double.tryParse(json['avg_rating']?.toString() ?? '0') ?? 0,
      totalReviews: json['total_reviews'] ?? 0,
      totalJobs: json['total_jobs'] ?? 0,
      isAvailableNow: json['is_available_now'] ?? false,
      availability: json['availability'] ?? 'offline',
      isOnline: user['is_online'] ?? false,
      distanceKm: json['distance_km'] != null ? double.tryParse(json['distance_km'].toString()) : null,
    );
  }
}

class ProfessionalDetailModel extends ProfessionalListModel {
  final String? bio;
  final double? latitude;
  final double? longitude;
  final int serviceRadiusKm;
  final String? portfolioDescription;
  final List<PortfolioItem> portfolioItems;

  const ProfessionalDetailModel({
    required super.id,
    required super.fullName,
    super.profilePhoto,
    required super.categories,
    required super.title,
    required super.city,
    super.hourlyRate,
    required super.experienceYears,
    required super.avgRating,
    required super.totalReviews,
    required super.totalJobs,
    required super.isAvailableNow,
    required super.availability,
    required super.isOnline,
    super.distanceKm,
    this.bio,
    this.latitude,
    this.longitude,
    this.serviceRadiusKm = 10,
    this.portfolioDescription,
    this.portfolioItems = const [],
  });

  factory ProfessionalDetailModel.fromJson(Map<String, dynamic> json) {
    final base = ProfessionalListModel.fromJson(json);
    return ProfessionalDetailModel(
      id: base.id,
      fullName: base.fullName,
      profilePhoto: base.profilePhoto,
      categories: base.categories,
      title: base.title,
      city: base.city,
      hourlyRate: base.hourlyRate,
      experienceYears: base.experienceYears,
      avgRating: base.avgRating,
      totalReviews: base.totalReviews,
      totalJobs: base.totalJobs,
      isAvailableNow: base.isAvailableNow,
      availability: base.availability,
      isOnline: base.isOnline,
      bio: json['user']?['bio'],
      latitude: json['latitude']?.toDouble(),
      longitude: json['longitude']?.toDouble(),
      serviceRadiusKm: json['service_radius_km'] ?? 10,
      portfolioDescription: json['portfolio_description'],
      portfolioItems: (json['portfolio_items'] as List? ?? [])
          .map((p) => PortfolioItem.fromJson(p))
          .toList(),
    );
  }
}

class PortfolioItem {
  final int id;
  final String title;
  final String? description;
  final String image;

  const PortfolioItem({required this.id, required this.title, this.description, required this.image});

  factory PortfolioItem.fromJson(Map<String, dynamic> json) => PortfolioItem(
        id: json['id'],
        title: json['title'] ?? '',
        description: json['description'],
        image: json['image'] ?? '',
      );
}
