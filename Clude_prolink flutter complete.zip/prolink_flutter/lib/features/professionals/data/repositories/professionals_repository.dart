import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/utils/api_client.dart';
import '../models/professional_model.dart';

class ProfessionalsRepository {
  final Dio _dio;
  ProfessionalsRepository(this._dio);

  Future<List<CategoryModel>> getCategories() async {
    final res = await _dio.get('/professionals/categories/');
    return (res.data as List).map((e) => CategoryModel.fromJson(e)).toList();
  }

  Future<Map<String, dynamic>> getProfessionals({
    int page = 1,
    int? categoryId,
    String? city,
    double? minRating,
    bool? availableNow,
    String? search,
    String ordering = '-avg_rating',
  }) async {
    final params = <String, dynamic>{
      'page': page,
      'ordering': ordering,
      if (categoryId != null) 'category': categoryId,
      if (city != null) 'city': city,
      if (minRating != null) 'min_rating': minRating,
      if (availableNow != null) 'available_now': availableNow,
      if (search != null && search.isNotEmpty) 'search': search,
    };
    final res = await _dio.get('/professionals/', queryParameters: params);
    final data = res.data;
    return {
      'results': (data['results'] as List).map((e) => ProfessionalListModel.fromJson(e)).toList(),
      'count': data['count'] ?? 0,
      'next': data['next'],
    };
  }

  Future<ProfessionalDetailModel> getProfessionalDetail(String id) async {
    final res = await _dio.get('/professionals/$id/');
    return ProfessionalDetailModel.fromJson(res.data);
  }

  Future<List<ProfessionalListModel>> getNearby({
    required double lat,
    required double lng,
    double radius = 10,
    int? categoryId,
  }) async {
    final params = <String, dynamic>{
      'lat': lat,
      'lng': lng,
      'radius': radius,
      if (categoryId != null) 'category': categoryId,
    };
    final res = await _dio.get('/professionals/nearby/', queryParameters: params);
    return (res.data as List).map((e) => ProfessionalListModel.fromJson(e)).toList();
  }
}

final professionalsRepositoryProvider = Provider<ProfessionalsRepository>(
  (ref) => ProfessionalsRepository(ref.read(dioProvider)),
);

// Providers
final categoriesProvider = FutureProvider<List<CategoryModel>>((ref) {
  return ref.read(professionalsRepositoryProvider).getCategories();
});

class ProfessionalsFilter {
  final int? categoryId;
  final String? city;
  final double? minRating;
  final bool? availableNow;
  final String? search;
  final String ordering;
  final int page;

  const ProfessionalsFilter({
    this.categoryId,
    this.city,
    this.minRating,
    this.availableNow,
    this.search,
    this.ordering = '-avg_rating',
    this.page = 1,
  });

  ProfessionalsFilter copyWith({
    int? categoryId,
    String? city,
    double? minRating,
    bool? availableNow,
    String? search,
    String? ordering,
    int? page,
    bool clearCategory = false,
  }) =>
      ProfessionalsFilter(
        categoryId: clearCategory ? null : (categoryId ?? this.categoryId),
        city: city ?? this.city,
        minRating: minRating ?? this.minRating,
        availableNow: availableNow ?? this.availableNow,
        search: search ?? this.search,
        ordering: ordering ?? this.ordering,
        page: page ?? this.page,
      );
}

final professionalsFilterProvider = StateProvider<ProfessionalsFilter>((ref) => const ProfessionalsFilter());

final professionalsProvider = FutureProvider<Map<String, dynamic>>((ref) {
  final filter = ref.watch(professionalsFilterProvider);
  final repo = ref.read(professionalsRepositoryProvider);
  return repo.getProfessionals(
    page: filter.page,
    categoryId: filter.categoryId,
    city: filter.city,
    minRating: filter.minRating,
    availableNow: filter.availableNow,
    search: filter.search,
    ordering: filter.ordering,
  );
});
