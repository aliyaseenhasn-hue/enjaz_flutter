import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/utils/api_client.dart';

class MessageModel {
  final String id;
  final Map<String, dynamic> sender;
  final String messageType;
  final String content;
  final bool isRead;
  final String createdAt;

  const MessageModel({required this.id, required this.sender, required this.messageType, required this.content, required this.isRead, required this.createdAt});

  factory MessageModel.fromJson(Map<String, dynamic> json) => MessageModel(
        id: json['id'] ?? '',
        sender: json['sender'] ?? {},
        messageType: json['message_type'] ?? 'text',
        content: json['content'] ?? '',
        isRead: json['is_read'] ?? false,
        createdAt: json['created_at'] ?? '',
      );
}

class ConversationModel {
  final String id;
  final Map<String, dynamic>? otherParticipant;
  final MessageModel? lastMessage;
  final int unreadCount;
  final String updatedAt;

  const ConversationModel({required this.id, this.otherParticipant, this.lastMessage, required this.unreadCount, required this.updatedAt});

  factory ConversationModel.fromJson(Map<String, dynamic> json) => ConversationModel(
        id: json['id'] ?? '',
        otherParticipant: json['other_participant'],
        lastMessage: json['last_message'] != null ? MessageModel.fromJson(json['last_message']) : null,
        unreadCount: json['unread_count'] ?? 0,
        updatedAt: json['updated_at'] ?? '',
      );
}

class ChatRepository {
  final Dio _dio;
  ChatRepository(this._dio);

  Future<List<ConversationModel>> getConversations() async {
    final res = await _dio.get('/chat/');
    final data = res.data['results'] ?? res.data;
    return (data as List).map((e) => ConversationModel.fromJson(e)).toList();
  }

  Future<ConversationModel> startConversation(String userId, {String? requestId}) async {
    final res = await _dio.post('/chat/start/', data: {'user_id': userId, if (requestId != null) 'request_id': requestId});
    return ConversationModel.fromJson(res.data);
  }

  Future<List<MessageModel>> getMessages(String conversationId) async {
    final res = await _dio.get('/chat/$conversationId/messages/');
    final data = res.data['results'] ?? res.data;
    return (data as List).map((e) => MessageModel.fromJson(e)).toList();
  }
}

final chatRepositoryProvider = Provider<ChatRepository>((ref) => ChatRepository(ref.read(dioProvider)));

final conversationsProvider = FutureProvider<List<ConversationModel>>((ref) {
  return ref.read(chatRepositoryProvider).getConversations();
});

final messagesProvider = FutureProvider.family<List<MessageModel>, String>((ref, convId) {
  return ref.read(chatRepositoryProvider).getMessages(convId);
});
