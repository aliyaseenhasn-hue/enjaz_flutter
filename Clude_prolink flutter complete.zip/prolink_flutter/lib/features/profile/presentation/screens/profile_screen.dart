import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/auth_state.dart';
import '../../../../core/utils/api_client.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).user;
    if (user == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(
        title: const Text('حسابي'),
        actions: [
          IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => context.push('/profile/edit')),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header
            Container(
              color: AppColors.surface,
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Stack(
                    children: [
                      CircleAvatar(
                        radius: 48,
                        backgroundColor: AppColors.primaryLight,
                        backgroundImage: user.profilePhoto != null ? CachedNetworkImageProvider(user.profilePhoto!) : null,
                        child: user.profilePhoto == null
                            ? Text(user.fullName[0], style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w700, color: AppColors.primary))
                            : null,
                      ),
                      if (user.isVerified)
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            width: 24, height: 24,
                            decoration: const BoxDecoration(color: AppColors.secondary, shape: BoxShape.circle),
                            child: const Icon(Icons.check, size: 14, color: Colors.white),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(user.fullName, style: const TextStyle(fontFamily: 'Cairo', fontSize: 20, fontWeight: FontWeight.w700)),
                  Text(user.phone, style: const TextStyle(fontFamily: 'Cairo', color: AppColors.textSecondary, fontSize: 14)),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _Badge(label: user.isProfessional ? 'مهني' : 'عميل', color: AppColors.primary),
                      const SizedBox(width: 8),
                      if (user.isIdentityVerified)
                        const _Badge(label: 'موثق ✓', color: AppColors.secondary)
                      else
                        _Badge(label: 'غير موثق', color: AppColors.warning),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // Identity Verification Banner
            if (!user.isIdentityVerified)
              GestureDetector(
                onTap: () => context.push('/auth/identity'),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFFBEB),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.warning),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.warning_amber_outlined, color: AppColors.warning),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text('قم بتوثيق هويتك لزيادة مصداقيتك\nاضغط هنا للتوثيق',
                            style: TextStyle(fontFamily: 'Cairo', fontSize: 13, color: AppColors.warning, height: 1.5)),
                      ),
                      Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.warning),
                    ],
                  ),
                ),
              ),

            // Menu Items
            _MenuSection(title: 'الحساب', items: [
              _MenuItem(icon: Icons.person_outline, label: 'تعديل الملف الشخصي', onTap: () => context.push('/profile/edit')),
              if (user.isProfessional)
                _MenuItem(icon: Icons.work_outline, label: 'إدارة ملفي المهني', onTap: () => context.push('/professionals/me')),
              _MenuItem(icon: Icons.lock_outline, label: 'تغيير كلمة المرور', onTap: () {}),
            ]),

            _MenuSection(title: 'الأمان', items: [
              _MenuItem(
                icon: Icons.verified_user_outlined,
                label: 'توثيق الهوية',
                trailing: user.isIdentityVerified
                    ? const Icon(Icons.check_circle, color: AppColors.secondary, size: 18)
                    : const Icon(Icons.warning_amber, color: AppColors.warning, size: 18),
                onTap: () => context.push('/auth/identity'),
              ),
            ]),

            _MenuSection(title: '', items: [
              _MenuItem(
                icon: Icons.logout,
                label: 'تسجيل الخروج',
                iconColor: AppColors.error,
                textColor: AppColors.error,
                onTap: () async {
                  final confirmed = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                    title: const Text('تسجيل الخروج'),
                    content: const Text('هل أنت متأكد من تسجيل الخروج؟'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                      ElevatedButton(onPressed: () => Navigator.pop(context, true), style: ElevatedButton.styleFrom(backgroundColor: AppColors.error), child: const Text('خروج')),
                    ],
                  ));
                  if (confirmed == true) {
                    await ref.read(authStateProvider.notifier).logout();
                    if (context.mounted) context.go('/auth/login');
                  }
                },
              ),
            ]),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  const _Badge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
      child: Text(label, style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: color, fontWeight: FontWeight.w600)),
    );
  }
}

class _MenuSection extends StatelessWidget {
  final String title;
  final List<_MenuItem> items;
  const _MenuSection({required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (title.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(title, style: const TextStyle(fontFamily: 'Cairo', fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textSecondary)),
          ),
        Container(
          color: AppColors.surface,
          child: Column(children: items.map((item) => item.build(context)).toList()),
        ),
      ],
    );
  }
}

class _MenuItem {
  final IconData icon;
  final String label;
  final Widget? trailing;
  final Color? iconColor, textColor;
  final VoidCallback onTap;

  const _MenuItem({required this.icon, required this.label, this.trailing, this.iconColor, this.textColor, required this.onTap});

  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, size: 22, color: iconColor ?? AppColors.textSecondary),
      title: Text(label, style: TextStyle(fontFamily: 'Cairo', fontSize: 14, color: textColor ?? AppColors.textPrimary)),
      trailing: trailing ?? const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.textHint),
    );
  }
}
