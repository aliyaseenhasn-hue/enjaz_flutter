import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/auth_state.dart';
import '../../../../core/utils/api_client.dart';

class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({super.key});

  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameCtrl;
  late final TextEditingController _bioCtrl;
  late final TextEditingController _cityCtrl;
  File? _pickedImage;
  bool _loading = false;

  final List<String> _iraqiCities = [
    'بغداد', 'البصرة', 'الموصل', 'أربيل', 'النجف',
    'كربلاء', 'الحلة', 'كركوك', 'الناصرية', 'العمارة',
    'الديوانية', 'الكوت', 'السماوة', 'تكريت', 'الرمادي',
    'الفلوجة', 'بعقوبة', 'السليمانية', 'دهوك', 'الحويجة',
  ];

  @override
  void initState() {
    super.initState();
    final user = ref.read(authStateProvider).user;
    _nameCtrl = TextEditingController(text: user?.fullName ?? '');
    _bioCtrl = TextEditingController(text: user?.bio ?? '');
    _cityCtrl = TextEditingController(text: user?.city ?? '');
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _bioCtrl.dispose();
    _cityCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final result = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 85,
    );
    if (result != null) {
      setState(() => _pickedImage = File(result.path));
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);

    try {
      final dio = ref.read(dioProvider);
      final formData = FormData.fromMap({
        'full_name': _nameCtrl.text.trim(),
        'bio': _bioCtrl.text.trim(),
        'city': _cityCtrl.text.trim(),
        if (_pickedImage != null)
          'profile_photo': await MultipartFile.fromFile(
            _pickedImage!.path,
            filename: 'photo.jpg',
          ),
      });

      final response = await dio.put('/auth/profile/', data: formData);
      final notifier = ref.read(authStateProvider.notifier);
      final current = ref.read(authStateProvider).user!;
      final updated = current.copyWith(
        fullName: response.data['full_name'],
        bio: response.data['bio'],
        city: response.data['city'],
        profilePhoto: response.data['profile_photo'],
      );
      await notifier.updateUser(updated);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تم تحديث الملف الشخصي'),
            backgroundColor: AppColors.secondary,
          ),
        );
        context.pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(extractApiError(e as DioException))),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authStateProvider).user;

    return Scaffold(
      appBar: AppBar(
        title: const Text('تعديل الملف الشخصي'),
        actions: [
          TextButton(
            onPressed: _loading ? null : _save,
            child: _loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text(
                    'حفظ',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary,
                    ),
                  ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Avatar picker
              GestureDetector(
                onTap: _pickImage,
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 56,
                      backgroundColor: AppColors.primaryLight,
                      backgroundImage: _pickedImage != null
                          ? FileImage(_pickedImage!)
                          : (user?.profilePhoto != null
                              ? CachedNetworkImageProvider(user!.profilePhoto!)
                              : null) as ImageProvider?,
                      child: (_pickedImage == null && user?.profilePhoto == null)
                          ? Text(
                              (user?.fullName.isNotEmpty == true)
                                  ? user!.fullName[0]
                                  : '؟',
                              style: const TextStyle(
                                fontSize: 44,
                                fontWeight: FontWeight.w700,
                                color: AppColors.primary,
                              ),
                            )
                          : null,
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'اضغط لتغيير الصورة',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12,
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 32),

              // Full name
              _buildField(
                controller: _nameCtrl,
                label: 'الاسم الكامل',
                icon: Icons.person_outline,
                validator: (v) => (v?.trim().isEmpty ?? true) ? 'الاسم مطلوب' : null,
              ),
              const SizedBox(height: 16),

              // City dropdown
              _buildCityField(),
              const SizedBox(height: 16),

              // Bio
              _buildField(
                controller: _bioCtrl,
                label: 'نبذة عني',
                icon: Icons.info_outline,
                maxLines: 4,
                hint: 'اكتب نبذة مختصرة عن نفسك...',
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    int maxLines = 1,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      validator: validator,
      textDirection: TextDirection.rtl,
      style: const TextStyle(fontFamily: 'Cairo'),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: AppColors.textSecondary),
        labelStyle: const TextStyle(fontFamily: 'Cairo'),
        hintStyle: const TextStyle(fontFamily: 'Cairo', color: AppColors.textHint),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.primary, width: 2),
        ),
        filled: true,
        fillColor: AppColors.surface,
      ),
    );
  }

  Widget _buildCityField() {
    return DropdownButtonFormField<String>(
      value: _iraqiCities.contains(_cityCtrl.text) ? _cityCtrl.text : null,
      style: const TextStyle(fontFamily: 'Cairo', color: AppColors.textPrimary),
      decoration: InputDecoration(
        labelText: 'المدينة',
        prefixIcon: const Icon(Icons.location_on_outlined, color: AppColors.textSecondary),
        labelStyle: const TextStyle(fontFamily: 'Cairo'),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.primary, width: 2),
        ),
        filled: true,
        fillColor: AppColors.surface,
      ),
      items: _iraqiCities
          .map((c) => DropdownMenuItem(value: c, child: Text(c, style: const TextStyle(fontFamily: 'Cairo'))))
          .toList(),
      onChanged: (v) {
        if (v != null) _cityCtrl.text = v;
      },
    );
  }
}
