// ─── Models ──────────────────────────────────────────────────────────────────

class PriceOffer {
  final int id;
  final String offeredBy;
  final double amount;
  final String? note;
  final bool isAccepted;
  final String createdAt;

  const PriceOffer({required this.id, required this.offeredBy, required this.amount, this.note, required this.isAccepted, required this.createdAt});

  factory PriceOffer.fromJson(Map<String, dynamic> json) => PriceOffer(
        id: json['id'],
        offeredBy: json['offered_by'] ?? '',
        amount: double.tryParse(json['amount'].toString()) ?? 0,
        note: json['note'],
        isAccepted: json['is_accepted'] ?? false,
        createdAt: json['created_at'] ?? '',
      );
}

class ServiceRequest {
  final String id;
  final Map<String, dynamic> seeker;
  final Map<String, dynamic>? professional;
  final int? categoryId;
  final String title;
  final String description;
  final String address;
  final String? scheduledDate;
  final String? scheduledTime;
  final bool isUrgent;
  final double? seekerBudget;
  final double? finalPrice;
  final String status;
  final String statusDisplay;
  final List<PriceOffer> priceOffers;
  final List<String> images;
  final String createdAt;

  const ServiceRequest({
    required this.id,
    required this.seeker,
    this.professional,
    this.categoryId,
    required this.title,
    required this.description,
    required this.address,
    this.scheduledDate,
    this.scheduledTime,
    this.isUrgent = false,
    this.seekerBudget,
    this.finalPrice,
    required this.status,
    required this.statusDisplay,
    this.priceOffers = const [],
    this.images = const [],
    required this.createdAt,
  });

  factory ServiceRequest.fromJson(Map<String, dynamic> json) => ServiceRequest(
        id: json['id'] ?? '',
        seeker: json['seeker'] ?? {},
        professional: json['professional'],
        categoryId: json['category'],
        title: json['title'] ?? '',
        description: json['description'] ?? '',
        address: json['address'] ?? '',
        scheduledDate: json['scheduled_date'],
        scheduledTime: json['scheduled_time'],
        isUrgent: json['is_urgent'] ?? false,
        seekerBudget: json['seeker_budget'] != null ? double.tryParse(json['seeker_budget'].toString()) : null,
        finalPrice: json['final_price'] != null ? double.tryParse(json['final_price'].toString()) : null,
        status: json['status'] ?? 'pending',
        statusDisplay: json['status_display'] ?? '',
        priceOffers: (json['price_offers'] as List? ?? []).map((o) => PriceOffer.fromJson(o)).toList(),
        images: (json['images'] as List? ?? []).map((i) => i['image'].toString()).toList(),
        createdAt: json['created_at'] ?? '',
      );

  Color get statusColor {
    switch (status) {
      case 'pending': return const Color(0xFFF59E0B);
      case 'accepted': case 'confirmed': return const Color(0xFF2563EB);
      case 'in_progress': return const Color(0xFF8B5CF6);
      case 'completed': return const Color(0xFF10B981);
      case 'cancelled': case 'rejected': return const Color(0xFFEF4444);
      default: return const Color(0xFF64748B);
    }
  }
}

// ─── Repository ──────────────────────────────────────────────────────────────

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/utils/api_client.dart';

class RequestsRepository {
  final Dio _dio;
  RequestsRepository(this._dio);

  Future<List<ServiceRequest>> getMyRequests({String? status}) async {
    final params = <String, dynamic>{if (status != null) 'status': status};
    final res = await _dio.get('/requests/', queryParameters: params);
    final results = res.data['results'] ?? res.data;
    return (results as List).map((e) => ServiceRequest.fromJson(e)).toList();
  }

  Future<ServiceRequest> getRequestDetail(String id) async {
    final res = await _dio.get('/requests/$id/');
    return ServiceRequest.fromJson(res.data);
  }

  Future<ServiceRequest> createRequest(Map<String, dynamic> data) async {
    final res = await _dio.post('/requests/create/', data: data);
    return ServiceRequest.fromJson(res.data);
  }

  Future<void> acceptRequest(String id) => _dio.post('/requests/$id/accept/');
  Future<void> rejectRequest(String id) => _dio.post('/requests/$id/reject/');
  Future<void> cancelRequest(String id) => _dio.post('/requests/$id/cancel/');
  Future<void> completeRequest(String id) => _dio.post('/requests/$id/complete/');

  Future<PriceOffer> makeOffer(String requestId, double amount, {String? note}) async {
    final res = await _dio.post('/requests/$requestId/offer/', data: {'amount': amount, if (note != null) 'note': note});
    return PriceOffer.fromJson(res.data);
  }

  Future<void> acceptOffer(String requestId, int offerId) =>
      _dio.post('/requests/$requestId/offer/$offerId/accept/');
}

final requestsRepositoryProvider = Provider<RequestsRepository>(
  (ref) => RequestsRepository(ref.read(dioProvider)),
);

final myRequestsProvider = FutureProvider.family<List<ServiceRequest>, String?>((ref, status) {
  return ref.read(requestsRepositoryProvider).getMyRequests(status: status);
});

final requestDetailProvider = FutureProvider.family<ServiceRequest, String>((ref, id) {
  return ref.read(requestsRepositoryProvider).getRequestDetail(id);
});
