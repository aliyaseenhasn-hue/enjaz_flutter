import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:dio/dio.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/auth_state.dart';
import '../../../../core/utils/api_client.dart';
import '../../data/models/request_model.dart';

class RequestDetailScreen extends ConsumerWidget {
  final String id;
  const RequestDetailScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final requestAsync = ref.watch(requestDetailProvider(id));
    final currentUser = ref.watch(authStateProvider).user;

    return requestAsync.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('$e'))),
      data: (req) => Scaffold(
        appBar: AppBar(
          title: const Text('تفاصيل الطلب'),
          actions: [
            Container(
              margin: const EdgeInsets.only(left: 16),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: req.statusColor.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
              child: Text(req.statusDisplay, style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w600, color: req.statusColor, fontSize: 12)),
            ),
          ],
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title & Description
              Text(req.title, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 8),
              Text(req.description, style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 16),

              // Info Cards
              _InfoCard(children: [
                _InfoRow(icon: Icons.location_on_outlined, label: 'العنوان', value: req.address),
                if (req.scheduledDate != null)
                  _InfoRow(icon: Icons.calendar_today_outlined, label: 'الموعد', value: '${req.scheduledDate} ${req.scheduledTime ?? ''}'),
                if (req.seekerBudget != null)
                  _InfoRow(icon: Icons.account_balance_wallet_outlined, label: 'الميزانية', value: '${req.seekerBudget!.toStringAsFixed(0)} د.ع'),
                if (req.finalPrice != null)
                  _InfoRow(icon: Icons.check_circle_outline, label: 'السعر النهائي', value: '${req.finalPrice!.toStringAsFixed(0)} د.ع', valueColor: AppColors.secondary),
              ]),
              const SizedBox(height: 20),

              // Price Offers (Negotiation)
              if (req.priceOffers.isNotEmpty) ...[
                const Text('التفاوض على السعر', style: TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 12),
                ...req.priceOffers.map((offer) => _OfferBubble(
                      offer: offer,
                      isMyOffer: offer.offeredBy == (currentUser?.isProfessional == true ? 'professional' : 'seeker'),
                      onAccept: (req.status == 'negotiating' && !offer.isAccepted)
                          ? () async {
                              await ref.read(requestsRepositoryProvider).acceptOffer(req.id, offer.id);
                              ref.invalidate(requestDetailProvider(id));
                            }
                          : null,
                    )),
                const SizedBox(height: 16),
              ],

              // Action Buttons
              _ActionButtons(request: req, currentUser: currentUser, requestId: id, ref: ref),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionButtons extends StatelessWidget {
  final ServiceRequest request;
  final dynamic currentUser;
  final String requestId;
  final WidgetRef ref;

  const _ActionButtons({required this.request, required this.currentUser, required this.requestId, required this.ref});

  bool get _isProfessional => currentUser?.isProfessional == true;

  @override
  Widget build(BuildContext context) {
    final status = request.status;

    return Column(
      children: [
        // Professional actions
        if (_isProfessional && status == 'pending') ...[
          ElevatedButton(
            onPressed: () async {
              await ref.read(requestsRepositoryProvider).acceptRequest(requestId);
              ref.invalidate(requestDetailProvider(requestId));
            },
            child: const Text('قبول الطلب'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: () async {
              await ref.read(requestsRepositoryProvider).rejectRequest(requestId);
              ref.invalidate(requestDetailProvider(requestId));
            },
            style: OutlinedButton.styleFrom(foregroundColor: AppColors.error, side: const BorderSide(color: AppColors.error)),
            child: const Text('رفض الطلب'),
          ),
        ],

        // In progress -> complete (professional)
        if (_isProfessional && status == 'in_progress')
          ElevatedButton(
            onPressed: () async {
              await ref.read(requestsRepositoryProvider).completeRequest(requestId);
              ref.invalidate(requestDetailProvider(requestId));
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.secondary),
            child: const Text('تأكيد إكمال الخدمة'),
          ),

        // Make price offer (both parties during negotiating/accepted)
        if (['accepted', 'negotiating'].contains(status))
          OutlinedButton.icon(
            onPressed: () => _showOfferDialog(context),
            icon: const Icon(Icons.price_change_outlined),
            label: const Text('عرض سعر'),
          ),

        // Start chat
        if (['accepted', 'negotiating', 'confirmed', 'in_progress'].contains(status))
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: OutlinedButton.icon(
              onPressed: () {
                final otherId = _isProfessional ? request.seeker['id'] : request.professional?['user']?['id'];
                if (otherId != null) context.push('/chat/start', extra: {'user_id': otherId, 'request_id': request.id});
              },
              icon: const Icon(Icons.chat_bubble_outline),
              label: const Text('فتح المحادثة'),
            ),
          ),

        // Add review after completion
        if (!_isProfessional && status == 'completed')
          ElevatedButton.icon(
            onPressed: () => context.push('/reviews/add', extra: {
              'professional_id': request.professional?['id'],
              'request_id': request.id,
            }),
            icon: const Icon(Icons.star_outline),
            label: const Text('تقييم المهني'),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.starColor),
          ),

        // Cancel
        if (['pending', 'accepted', 'negotiating'].contains(status))
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: TextButton(
              onPressed: () async {
                final confirmed = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                  title: const Text('تأكيد الإلغاء'),
                  content: const Text('هل أنت متأكد من إلغاء هذا الطلب؟'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لا')),
                    ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('نعم، إلغاء')),
                  ],
                ));
                if (confirmed == true) {
                  await ref.read(requestsRepositoryProvider).cancelRequest(requestId);
                  ref.invalidate(requestDetailProvider(requestId));
                }
              },
              child: const Text('إلغاء الطلب', style: TextStyle(color: AppColors.error)),
            ),
          ),
      ],
    );
  }

  void _showOfferDialog(BuildContext context) {
    final ctrl = TextEditingController();
    final noteCtrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('عرض سعر جديد', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 16),
            TextField(controller: ctrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ (د.ع)', prefixIcon: Icon(Icons.payments_outlined))),
            const SizedBox(height: 12),
            TextField(controller: noteCtrl, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)')),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                if (ctrl.text.isEmpty) return;
                Navigator.pop(context);
                await ref.read(requestsRepositoryProvider).makeOffer(requestId, double.parse(ctrl.text), note: noteCtrl.text.isNotEmpty ? noteCtrl.text : null);
                ref.invalidate(requestDetailProvider(requestId));
              },
              child: const Text('إرسال العرض'),
            ),
          ],
        ),
      ),
    );
  }
}

class _OfferBubble extends StatelessWidget {
  final PriceOffer offer;
  final bool isMyOffer;
  final VoidCallback? onAccept;

  const _OfferBubble({required this.offer, required this.isMyOffer, this.onAccept});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isMyOffer ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        constraints: const BoxConstraints(maxWidth: 260),
        decoration: BoxDecoration(
          color: offer.isAccepted ? AppColors.secondaryLight : (isMyOffer ? AppColors.primaryLight : AppColors.divider),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: offer.isAccepted ? AppColors.secondary : AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${offer.amount.toStringAsFixed(0)} د.ع', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700, color: offer.isAccepted ? AppColors.secondary : AppColors.textPrimary)),
            if (offer.note != null && offer.note!.isNotEmpty)
              Text(offer.note!, style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppColors.textSecondary)),
            if (offer.isAccepted)
              const Row(children: [Icon(Icons.check_circle, size: 14, color: AppColors.secondary), SizedBox(width: 4), Text('تم القبول', style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppColors.secondary, fontWeight: FontWeight.w600))]),
            if (!offer.isAccepted && !isMyOffer && onAccept != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: ElevatedButton(
                  onPressed: onAccept,
                  style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 34), padding: EdgeInsets.zero),
                  child: const Text('قبول هذا السعر', style: TextStyle(fontSize: 12)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final List<Widget> children;
  const _InfoCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.divider, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label, value;
  final Color? valueColor;
  const _InfoRow({required this.icon, required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppColors.textSecondary),
          const SizedBox(width: 8),
          Text('$label: ', style: const TextStyle(fontFamily: 'Cairo', fontSize: 13, color: AppColors.textSecondary)),
          Expanded(child: Text(value, style: TextStyle(fontFamily: 'Cairo', fontSize: 13, fontWeight: FontWeight.w600, color: valueColor ?? AppColors.textPrimary))),
        ],
      ),
    );
  }
}
