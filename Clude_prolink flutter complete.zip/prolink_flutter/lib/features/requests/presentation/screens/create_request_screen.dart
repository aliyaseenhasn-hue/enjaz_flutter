import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:dio/dio.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/api_client.dart';
import '../../data/models/request_model.dart';

class CreateRequestScreen extends ConsumerStatefulWidget {
  final Map<String, dynamic> extra;
  const CreateRequestScreen({super.key, required this.extra});

  @override
  ConsumerState<CreateRequestScreen> createState() => _CreateRequestScreenState();
}

class _CreateRequestScreenState extends ConsumerState<CreateRequestScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _budgetCtrl = TextEditingController();
  bool _isUrgent = false;
  bool _loading = false;
  DateTime? _scheduledDate;
  TimeOfDay? _scheduledTime;

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _addressCtrl.dispose();
    _budgetCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final repo = ref.read(requestsRepositoryProvider);
      final req = await repo.createRequest({
        'professional': widget.extra['professional_id'],
        'title': _titleCtrl.text.trim(),
        'description': _descCtrl.text.trim(),
        'address': _addressCtrl.text.trim(),
        'is_urgent': _isUrgent,
        if (_budgetCtrl.text.isNotEmpty) 'seeker_budget': double.parse(_budgetCtrl.text),
        if (_scheduledDate != null) 'scheduled_date': _scheduledDate!.toIso8601String().split('T')[0],
        if (_scheduledTime != null) 'scheduled_time': '${_scheduledTime!.hour.toString().padLeft(2, '0')}:${_scheduledTime!.minute.toString().padLeft(2, '0')}',
      });
      if (mounted) {
        context.go('/requests/${req.id}');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إرسال طلبك بنجاح ✅'), backgroundColor: AppColors.secondary),
        );
      }
    } on DioException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(extractApiError(e)), backgroundColor: AppColors.error),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('طلب خدمة من ${widget.extra['professional_name'] ?? ''}')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Urgent toggle
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _isUrgent ? const Color(0xFFFEF2F2) : AppColors.divider,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _isUrgent ? AppColors.error : AppColors.border),
                ),
                child: Row(
                  children: [
                    const Text('🚨', style: TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('طلب عاجل', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w600)),
                          Text(_isUrgent ? 'سيتم إشعار المهني فوراً' : 'اضغط لتفعيل الخدمة العاجلة',
                              style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppColors.textSecondary)),
                        ],
                      ),
                    ),
                    Switch(value: _isUrgent, onChanged: (v) => setState(() => _isUrgent = v), activeColor: AppColors.error),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              TextFormField(
                controller: _titleCtrl,
                decoration: const InputDecoration(labelText: 'عنوان الطلب', hintText: 'مثال: إصلاح تسريب مياه في الحمام'),
                validator: (v) => v == null || v.isEmpty ? 'أدخل عنوان الطلب' : null,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _descCtrl,
                maxLines: 4,
                decoration: const InputDecoration(labelText: 'وصف تفصيلي', hintText: 'اشرح المشكلة بالتفصيل لمساعدة المهني'),
                validator: (v) => v == null || v.length < 10 ? 'أدخل وصفاً كافياً' : null,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _addressCtrl,
                decoration: const InputDecoration(labelText: 'العنوان', prefixIcon: Icon(Icons.location_on_outlined), hintText: 'المحلة، الشارع، رقم البيت'),
                validator: (v) => v == null || v.isEmpty ? 'أدخل العنوان' : null,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _budgetCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'الميزانية المقترحة (اختياري)', prefixIcon: Icon(Icons.payments_outlined), suffixText: 'د.ع'),
              ),
              const SizedBox(height: 16),

              // Date & Time
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now().add(const Duration(days: 1)),
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(const Duration(days: 60)),
                        );
                        if (d != null) setState(() => _scheduledDate = d);
                      },
                      child: _DateField(
                        icon: Icons.calendar_today_outlined,
                        label: 'التاريخ',
                        value: _scheduledDate != null
                            ? '${_scheduledDate!.day}/${_scheduledDate!.month}/${_scheduledDate!.year}'
                            : null,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
                        if (t != null) setState(() => _scheduledTime = t);
                      },
                      child: _DateField(
                        icon: Icons.access_time_outlined,
                        label: 'الوقت',
                        value: _scheduledTime?.format(context),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 40),

              ElevatedButton(
                onPressed: _loading ? null : _submit,
                child: _loading
                    ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                    : const Text('إرسال الطلب'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DateField extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? value;
  const _DateField({required this.icon, required this.label, this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.divider,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: value != null ? AppColors.primary : AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: value != null ? AppColors.primary : AppColors.textHint),
          const SizedBox(width: 8),
          Text(
            value ?? label,
            style: TextStyle(fontFamily: 'Cairo', fontSize: 13, color: value != null ? AppColors.textPrimary : AppColors.textHint),
          ),
        ],
      ),
    );
  }
}
