class UserModel {
  final String id;
  final String phone;
  final String? email;
  final String fullName;
  final String role;
  final String? profilePhoto;
  final String? bio;
  final String? city;
  final bool isPhoneVerified;
  final bool isIdentityVerified;
  final bool isVerified;
  final bool isOnline;
  final String? lastSeen;
  final String? createdAt;

  const UserModel({
    required this.id,
    required this.phone,
    this.email,
    required this.fullName,
    required this.role,
    this.profilePhoto,
    this.bio,
    this.city,
    this.isPhoneVerified = false,
    this.isIdentityVerified = false,
    this.isVerified = false,
    this.isOnline = false,
    this.lastSeen,
    this.createdAt,
  });

  bool get isSeeker => role == 'seeker';
  bool get isProfessional => role == 'professional';

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: json['id'] ?? '',
        phone: json['phone'] ?? '',
        email: json['email'],
        fullName: json['full_name'] ?? '',
        role: json['role'] ?? 'seeker',
        profilePhoto: json['profile_photo'],
        bio: json['bio'],
        city: json['city'],
        isPhoneVerified: json['is_phone_verified'] ?? false,
        isIdentityVerified: json['is_identity_verified'] ?? false,
        isVerified: json['is_verified'] ?? false,
        isOnline: json['is_online'] ?? false,
        lastSeen: json['last_seen'],
        createdAt: json['created_at'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'phone': phone,
        'email': email,
        'full_name': fullName,
        'role': role,
        'profile_photo': profilePhoto,
        'bio': bio,
        'city': city,
        'is_phone_verified': isPhoneVerified,
        'is_identity_verified': isIdentityVerified,
        'is_verified': isVerified,
        'is_online': isOnline,
        'last_seen': lastSeen,
        'created_at': createdAt,
      };

  UserModel copyWith({
    String? fullName,
    String? profilePhoto,
    String? bio,
    String? city,
    bool? isIdentityVerified,
    bool? isVerified,
  }) =>
      UserModel(
        id: id,
        phone: phone,
        email: email,
        fullName: fullName ?? this.fullName,
        role: role,
        profilePhoto: profilePhoto ?? this.profilePhoto,
        bio: bio ?? this.bio,
        city: city ?? this.city,
        isPhoneVerified: isPhoneVerified,
        isIdentityVerified: isIdentityVerified ?? this.isIdentityVerified,
        isVerified: isVerified ?? this.isVerified,
        isOnline: isOnline,
        lastSeen: lastSeen,
        createdAt: createdAt,
      );
}
