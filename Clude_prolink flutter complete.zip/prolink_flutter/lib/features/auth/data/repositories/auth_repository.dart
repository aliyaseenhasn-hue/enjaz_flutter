import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/utils/api_client.dart';
import '../models/user_model.dart';

class AuthRepository {
  final Dio _dio;
  AuthRepository(this._dio);

  Future<Map<String, dynamic>> register({
    required String phone,
    required String fullName,
    required String role,
    required String password,
  }) async {
    final response = await _dio.post('/auth/register/', data: {
      'phone': phone,
      'full_name': fullName,
      'role': role,
      'password': password,
      'password_confirm': password,
    });
    return response.data;
  }

  Future<Map<String, dynamic>> verifyOtp({
    required String phone,
    required String code,
  }) async {
    final response = await _dio.post('/auth/verify-otp/', data: {
      'phone': phone,
      'code': code,
    });
    return {
      'access': response.data['access'],
      'refresh': response.data['refresh'],
      'user': UserModel.fromJson(response.data['user']),
    };
  }

  Future<void> resendOtp(String phone) async {
    await _dio.post('/auth/resend-otp/', data: {'phone': phone});
  }

  Future<Map<String, dynamic>> login({
    required String phone,
    required String password,
  }) async {
    final response = await _dio.post('/auth/login/', data: {
      'phone': phone,
      'password': password,
    });
    return {
      'access': response.data['access'],
      'refresh': response.data['refresh'],
      'user': UserModel.fromJson(response.data['user']),
    };
  }

  Future<void> logout(String refreshToken) async {
    await _dio.post('/auth/logout/', data: {'refresh': refreshToken});
  }

  Future<UserModel> getProfile() async {
    final response = await _dio.get('/auth/profile/');
    return UserModel.fromJson(response.data);
  }

  Future<UserModel> updateProfile(Map<String, dynamic> data) async {
    final response = await _dio.patch('/auth/profile/', data: data);
    return UserModel.fromJson(response.data);
  }

  Future<void> uploadIdentity({
    required String idFrontPath,
    required String idBackPath,
    required String photoPath,
    required String fullName,
  }) async {
    final formData = FormData.fromMap({
      'full_name': fullName,
      'national_id_front': await MultipartFile.fromFile(idFrontPath, filename: 'id_front.jpg'),
      'national_id_back': await MultipartFile.fromFile(idBackPath, filename: 'id_back.jpg'),
      'profile_photo': await MultipartFile.fromFile(photoPath, filename: 'photo.jpg'),
    });
    await _dio.put('/auth/profile/identity/', data: formData);
  }
}

final authRepositoryProvider = Provider<AuthRepository>(
  (ref) => AuthRepository(ref.read(dioProvider)),
);
