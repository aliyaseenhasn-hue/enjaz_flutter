import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dio/dio.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/api_client.dart';
import '../../data/repositories/auth_repository.dart';

class IdentityVerificationScreen extends ConsumerStatefulWidget {
  const IdentityVerificationScreen({super.key});

  @override
  ConsumerState<IdentityVerificationScreen> createState() => _IdentityVerificationScreenState();
}

class _IdentityVerificationScreenState extends ConsumerState<IdentityVerificationScreen> {
  File? _idFront, _idBack, _selfie;
  bool _loading = false;
  final _picker = ImagePicker();

  Future<void> _pick(ImageSource source, String type) async {
    final picked = await _picker.pickImage(source: source, imageQuality: 80);
    if (picked == null) return;
    setState(() {
      final file = File(picked.path);
      if (type == 'front') _idFront = file;
      else if (type == 'back') _idBack = file;
      else _selfie = file;
    });
  }

  Future<void> _submit() async {
    if (_idFront == null || _idBack == null || _selfie == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى رفع جميع الصور المطلوبة'), backgroundColor: AppColors.warning),
      );
      return;
    }
    setState(() => _loading = true);
    try {
      await ref.read(authRepositoryProvider).uploadIdentity(
        idFrontPath: _idFront!.path,
        idBackPath: _idBack!.path,
        photoPath: _selfie!.path,
        fullName: '',
      );
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: const Text('تم الإرسال ✅'),
            content: const Text('تم رفع وثائقك بنجاح. سيتم مراجعتها خلال 24 ساعة وسيُعلمك بالنتيجة.'),
            actions: [
              ElevatedButton(
                onPressed: () { Navigator.pop(context); context.go('/home'); },
                child: const Text('حسناً'),
              ),
            ],
          ),
        );
      }
    } on DioException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(extractApiError(e)), backgroundColor: AppColors.error),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('توثيق الهوية')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, color: AppColors.primary),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'توثيق الهوية يزيد من ثقة العملاء ويضمن بيئة آمنة للجميع.',
                      style: TextStyle(fontFamily: 'Cairo', fontSize: 13, color: AppColors.primary),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            _UploadCard(
              title: 'الوجه الأمامي للهوية',
              subtitle: 'صورة واضحة من الأمام',
              icon: Icons.credit_card_outlined,
              file: _idFront,
              onTap: () => _pick(ImageSource.camera, 'front'),
            ),
            const SizedBox(height: 16),
            _UploadCard(
              title: 'الوجه الخلفي للهوية',
              subtitle: 'صورة واضحة من الخلف',
              icon: Icons.credit_card,
              file: _idBack,
              onTap: () => _pick(ImageSource.camera, 'back'),
            ),
            const SizedBox(height: 16),
            _UploadCard(
              title: 'صورة شخصية (سيلفي)',
              subtitle: 'صورة واضحة لوجهك',
              icon: Icons.face_outlined,
              file: _selfie,
              onTap: () => _pick(ImageSource.camera, 'selfie'),
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: _loading ? null : _submit,
              child: _loading
                  ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                  : const Text('إرسال للمراجعة'),
            ),
            const SizedBox(height: 16),
            Center(
              child: TextButton(
                onPressed: () => context.go('/home'),
                child: const Text('لاحقاً', style: TextStyle(color: AppColors.textSecondary)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _UploadCard extends StatelessWidget {
  final String title, subtitle;
  final IconData icon;
  final File? file;
  final VoidCallback onTap;

  const _UploadCard({required this.title, required this.subtitle, required this.icon, this.file, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 120,
        decoration: BoxDecoration(
          color: file != null ? AppColors.secondaryLight : AppColors.divider,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: file != null ? AppColors.secondary : AppColors.border,
            width: 1.5,
          ),
        ),
        child: file != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.file(file!, fit: BoxFit.cover),
                    Container(
                      color: Colors.black.withOpacity(0.3),
                      child: const Icon(Icons.check_circle, color: Colors.white, size: 40),
                    ),
                  ],
                ),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 32, color: AppColors.textHint),
                  const SizedBox(height: 8),
                  Text(title, style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                  Text(subtitle, style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
      ),
    );
  }
}
