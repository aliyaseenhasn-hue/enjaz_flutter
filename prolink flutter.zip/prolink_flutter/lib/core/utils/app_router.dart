import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/auth/presentation/screens/otp_screen.dart';
import '../../features/auth/presentation/screens/identity_verification_screen.dart';
import '../../features/home/presentation/screens/main_screen.dart';
import '../../features/professionals/presentation/screens/professional_list_screen.dart';
import '../../features/professionals/presentation/screens/professional_detail_screen.dart';
import '../../features/requests/presentation/screens/create_request_screen.dart';
import '../../features/requests/presentation/screens/request_detail_screen.dart';
import '../../features/requests/presentation/screens/requests_list_screen.dart';
import '../../features/chat/presentation/screens/chat_list_screen.dart';
import '../../features/chat/presentation/screens/chat_screen.dart';
import '../../features/notifications/presentation/screens/notifications_screen.dart';
import '../../features/profile/presentation/screens/profile_screen.dart';
import '../../features/profile/presentation/screens/edit_profile_screen.dart';
import '../../features/reviews/presentation/screens/add_review_screen.dart';
import '../utils/auth_state.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: '/splash',
    redirect: (context, state) {
      final isLoggedIn = authState.isLoggedIn;
      final isOnAuthPage = state.matchedLocation.startsWith('/auth');
      final isSplash = state.matchedLocation == '/splash';

      if (isSplash) return null;
      if (!isLoggedIn && !isOnAuthPage) return '/auth/login';
      if (isLoggedIn && isOnAuthPage) return '/home';
      return null;
    },
    routes: [
      GoRoute(path: '/splash', builder: (_, __) => const SplashScreen()),

      // Auth routes
      GoRoute(path: '/auth/login', builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/auth/register', builder: (_, __) => const RegisterScreen()),
      GoRoute(
        path: '/auth/otp',
        builder: (_, state) => OtpScreen(phone: state.extra as String),
      ),
      GoRoute(
        path: '/auth/identity',
        builder: (_, __) => const IdentityVerificationScreen(),
      ),

      // Main shell with bottom nav
      ShellRoute(
        builder: (context, state, child) => MainScreen(child: child),
        routes: [
          GoRoute(path: '/home', builder: (_, __) => const ProfessionalListScreen()),
          GoRoute(
            path: '/professionals',
            builder: (_, __) => const ProfessionalListScreen(),
          ),
          GoRoute(
            path: '/professionals/:id',
            builder: (_, state) => ProfessionalDetailScreen(id: state.pathParameters['id']!),
          ),
          GoRoute(path: '/requests', builder: (_, __) => const RequestsListScreen()),
          GoRoute(
            path: '/requests/:id',
            builder: (_, state) => RequestDetailScreen(id: state.pathParameters['id']!),
          ),
          GoRoute(
            path: '/requests/create',
            builder: (_, state) => CreateRequestScreen(extra: state.extra as Map<String, dynamic>),
          ),
          GoRoute(path: '/chat', builder: (_, __) => const ChatListScreen()),
          GoRoute(
            path: '/chat/:id',
            builder: (_, state) => ChatScreen(
              conversationId: state.pathParameters['id']!,
              extra: state.extra as Map<String, dynamic>?,
            ),
          ),
          GoRoute(path: '/notifications', builder: (_, __) => const NotificationsScreen()),
          GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
          GoRoute(path: '/profile/edit', builder: (_, __) => const EditProfileScreen()),
          GoRoute(
            path: '/reviews/add',
            builder: (_, state) => AddReviewScreen(extra: state.extra as Map<String, dynamic>),
          ),
        ],
      ),
    ],
  );
});
